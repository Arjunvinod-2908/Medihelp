﻿# HeidiSQL Dump 
#
# --------------------------------------------------------
# Host:                         127.0.0.1
# Database:                     db_medihelp
# Server version:               5.0.51b-community-nt
# Server OS:                    Win32
# Target compatibility:         ANSI SQL
# HeidiSQL version:             4.0
# Date/time:                    2024-11-25 19:10:00
# --------------------------------------------------------

/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ANSI,NO_BACKSLASH_ESCAPES';*/
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;*/


#
# Database structure for database 'db_medihelp'
#

CREATE DATABASE /*!32312 IF NOT EXISTS*/ "db_medihelp" /*!40100 DEFAULT CHARACTER SET latin1 */;

USE "db_medihelp";


#
# Table structure for table 'tbl_admin'
#

CREATE TABLE /*!32312 IF NOT EXISTS*/ "tbl_admin" (
  "admin_id" int(10) unsigned NOT NULL auto_increment,
  "admin_name" varchar(50) default NULL,
  "admin_email" varchar(50) default NULL,
  "admin_password" varchar(50) default NULL,
  PRIMARY KEY  ("admin_id")
) AUTO_INCREMENT=14;



#
# Dumping data for table 'tbl_admin'
#

LOCK TABLES "tbl_admin" WRITE;
/*!40000 ALTER TABLE "tbl_admin" DISABLE KEYS;*/
REPLACE INTO "tbl_admin" ("admin_id", "admin_name", "admin_email", "admin_password") VALUES
	('10','aromal','aromal@gmail.com','aromal1');
REPLACE INTO "tbl_admin" ("admin_id", "admin_name", "admin_email", "admin_password") VALUES
	('11','arjun','arjun@gmail.com','arjun1');
REPLACE INTO "tbl_admin" ("admin_id", "admin_name", "admin_email", "admin_password") VALUES
	('12','Vishnu','vishnu@gmail.com','vishnu123');
REPLACE INTO "tbl_admin" ("admin_id", "admin_name", "admin_email", "admin_password") VALUES
	('13','Dr Panikker','panikker@gmail.com','panikker');
/*!40000 ALTER TABLE "tbl_admin" ENABLE KEYS;*/
UNLOCK TABLES;


#
# Table structure for table 'tbl_agerange'
#

CREATE TABLE /*!32312 IF NOT EXISTS*/ "tbl_agerange" (
  "age_id" int(10) unsigned NOT NULL auto_increment,
  "age_range" varchar(30) default NULL,
  PRIMARY KEY  ("age_id")
) AUTO_INCREMENT=10;



#
# Dumping data for table 'tbl_agerange'
#

LOCK TABLES "tbl_agerange" WRITE;
/*!40000 ALTER TABLE "tbl_agerange" DISABLE KEYS;*/
REPLACE INTO "tbl_agerange" ("age_id", "age_range") VALUES
	('3','18-20');
REPLACE INTO "tbl_agerange" ("age_id", "age_range") VALUES
	('4','20-25');
REPLACE INTO "tbl_agerange" ("age_id", "age_range") VALUES
	('5','25-30');
REPLACE INTO "tbl_agerange" ("age_id", "age_range") VALUES
	('7','60-65');
REPLACE INTO "tbl_agerange" ("age_id", "age_range") VALUES
	('8','65-70');
REPLACE INTO "tbl_agerange" ("age_id", "age_range") VALUES
	('9','70-95');
/*!40000 ALTER TABLE "tbl_agerange" ENABLE KEYS;*/
UNLOCK TABLES;


#
# Table structure for table 'tbl_booking'
#

CREATE TABLE /*!32312 IF NOT EXISTS*/ "tbl_booking" (
  "booking_id" int(11) NOT NULL auto_increment,
  "booking_date" varchar(100) NOT NULL default '',
  "booking_status" int(11) NOT NULL default '0',
  "booking_amount" varchar(100) NOT NULL default '',
  "user_id" int(11) NOT NULL,
  "agent_id" int(10) unsigned default NULL,
  "booking_prescription" varchar(50) default NULL,
  PRIMARY KEY  ("booking_id")
) AUTO_INCREMENT=56;



#
# Dumping data for table 'tbl_booking'
#

LOCK TABLES "tbl_booking" WRITE;
/*!40000 ALTER TABLE "tbl_booking" DISABLE KEYS;*/
REPLACE INTO "tbl_booking" ("booking_id", "booking_date", "booking_status", "booking_amount", "user_id", "agent_id", "booking_prescription") VALUES
	(50,'2024-11-13',2,'50.00',14,NULL,'booking_prescription1985.png');
REPLACE INTO "tbl_booking" ("booking_id", "booking_date", "booking_status", "booking_amount", "user_id", "agent_id", "booking_prescription") VALUES
	(51,'2024-11-13',1,'50.00',15,NULL,'booking_prescription1165.jpg');
REPLACE INTO "tbl_booking" ("booking_id", "booking_date", "booking_status", "booking_amount", "user_id", "agent_id", "booking_prescription") VALUES
	(52,'2024-11-13',1,'50.00',15,NULL,NULL);
REPLACE INTO "tbl_booking" ("booking_id", "booking_date", "booking_status", "booking_amount", "user_id", "agent_id", "booking_prescription") VALUES
	(53,'2024-11-13',2,'35.00',15,'11','booking_prescription1376.jpg');
REPLACE INTO "tbl_booking" ("booking_id", "booking_date", "booking_status", "booking_amount", "user_id", "agent_id", "booking_prescription") VALUES
	(54,'2024-11-13',2,'340.00',15,'11','booking_prescription1119.png');
REPLACE INTO "tbl_booking" ("booking_id", "booking_date", "booking_status", "booking_amount", "user_id", "agent_id", "booking_prescription") VALUES
	(55,'',0,'',14,NULL,NULL);
/*!40000 ALTER TABLE "tbl_booking" ENABLE KEYS;*/
UNLOCK TABLES;


#
# Table structure for table 'tbl_cart'
#

CREATE TABLE /*!32312 IF NOT EXISTS*/ "tbl_cart" (
  "cart_id" int(11) NOT NULL auto_increment,
  "cart_qty" int(11) NOT NULL default '1',
  "cart_status" int(11) NOT NULL default '0',
  "booking_id" int(11) NOT NULL,
  "medicine_id" int(11) NOT NULL,
  "emg_status" int(10) unsigned default '0',
  PRIMARY KEY  ("cart_id")
) AUTO_INCREMENT=83;



#
# Dumping data for table 'tbl_cart'
#

LOCK TABLES "tbl_cart" WRITE;
/*!40000 ALTER TABLE "tbl_cart" DISABLE KEYS;*/
REPLACE INTO "tbl_cart" ("cart_id", "cart_qty", "cart_status", "booking_id", "medicine_id", "emg_status") VALUES
	(69,1,2,45,17,'0');
REPLACE INTO "tbl_cart" ("cart_id", "cart_qty", "cart_status", "booking_id", "medicine_id", "emg_status") VALUES
	(70,1,2,46,17,'0');
REPLACE INTO "tbl_cart" ("cart_id", "cart_qty", "cart_status", "booking_id", "medicine_id", "emg_status") VALUES
	(71,1,3,47,17,'0');
REPLACE INTO "tbl_cart" ("cart_id", "cart_qty", "cart_status", "booking_id", "medicine_id", "emg_status") VALUES
	(72,1,2,48,17,'0');
REPLACE INTO "tbl_cart" ("cart_id", "cart_qty", "cart_status", "booking_id", "medicine_id", "emg_status") VALUES
	(73,1,6,49,16,'0');
REPLACE INTO "tbl_cart" ("cart_id", "cart_qty", "cart_status", "booking_id", "medicine_id", "emg_status") VALUES
	(74,1,2,50,18,'0');
REPLACE INTO "tbl_cart" ("cart_id", "cart_qty", "cart_status", "booking_id", "medicine_id", "emg_status") VALUES
	(75,1,1,51,18,'0');
REPLACE INTO "tbl_cart" ("cart_id", "cart_qty", "cart_status", "booking_id", "medicine_id", "emg_status") VALUES
	(76,1,1,52,18,'0');
REPLACE INTO "tbl_cart" ("cart_id", "cart_qty", "cart_status", "booking_id", "medicine_id", "emg_status") VALUES
	(77,1,6,53,19,'0');
REPLACE INTO "tbl_cart" ("cart_id", "cart_qty", "cart_status", "booking_id", "medicine_id", "emg_status") VALUES
	(78,4,6,54,19,'1');
REPLACE INTO "tbl_cart" ("cart_id", "cart_qty", "cart_status", "booking_id", "medicine_id", "emg_status") VALUES
	(79,1,0,55,18,'0');
REPLACE INTO "tbl_cart" ("cart_id", "cart_qty", "cart_status", "booking_id", "medicine_id", "emg_status") VALUES
	(80,1,0,55,19,'1');
REPLACE INTO "tbl_cart" ("cart_id", "cart_qty", "cart_status", "booking_id", "medicine_id", "emg_status") VALUES
	(81,1,0,55,20,'0');
REPLACE INTO "tbl_cart" ("cart_id", "cart_qty", "cart_status", "booking_id", "medicine_id", "emg_status") VALUES
	(82,1,0,55,21,'1');
/*!40000 ALTER TABLE "tbl_cart" ENABLE KEYS;*/
UNLOCK TABLES;


#
# Table structure for table 'tbl_complaint'
#

CREATE TABLE /*!32312 IF NOT EXISTS*/ "tbl_complaint" (
  "complaint_id" int(10) unsigned NOT NULL auto_increment,
  "complaint_date" varchar(50) default NULL,
  "user_id" int(10) unsigned default NULL,
  "complaint_message" varchar(50) default NULL,
  "complaint_status" varchar(50) default '0',
  "complaint_reply" varchar(50) default NULL,
  "complaint_replydate" varchar(50) default NULL,
  "booking_id" int(10) unsigned default NULL,
  PRIMARY KEY  ("complaint_id")
);



#
# Dumping data for table 'tbl_complaint'
#

# No data found.



#
# Table structure for table 'tbl_dagent'
#

CREATE TABLE /*!32312 IF NOT EXISTS*/ "tbl_dagent" (
  "agent_id" int(10) unsigned NOT NULL auto_increment,
  "agent_name" varchar(50) default NULL,
  "agent_age" varchar(50) default NULL,
  "agent_gender" varchar(50) default NULL,
  "agent_phone" varchar(50) default NULL,
  "agent_dob" varchar(50) default NULL,
  "agent_email" varchar(50) default NULL,
  "place_id" int(10) unsigned default NULL,
  "agent_address" varchar(50) default NULL,
  "agent_uname" varchar(50) default NULL,
  "agent_pswd" varchar(50) default NULL,
  "agent_proof_type" varchar(50) default NULL,
  "agent_proof_no" varchar(50) default NULL,
  "agent_proof" varchar(50) default NULL,
  "agent_dlicense_no" varchar(50) default NULL,
  "agent_dlicense" varchar(50) default NULL,
  "agent_photo" varchar(50) default NULL,
  "agent_vstatus" int(10) unsigned default '0',
  PRIMARY KEY  ("agent_id")
) AUTO_INCREMENT=13;



#
# Dumping data for table 'tbl_dagent'
#

LOCK TABLES "tbl_dagent" WRITE;
/*!40000 ALTER TABLE "tbl_dagent" DISABLE KEYS;*/
REPLACE INTO "tbl_dagent" ("agent_id", "agent_name", "agent_age", "agent_gender", "agent_phone", "agent_dob", "agent_email", "place_id", "agent_address", "agent_uname", "agent_pswd", "agent_proof_type", "agent_proof_no", "agent_proof", "agent_dlicense_no", "agent_dlicense", "agent_photo", "agent_vstatus") VALUES
	('11','Arjun Vinod','35','male','9207329902','2000-11-30','gouthamvikhneshwaran@gmail.com','9','Kolenchery,Udayam peroor','arjun','arjun','Aadhar','897546265893','agent_proof1084.jpg','DL1548965325','dagent_license1563.jpg','agent_photo1624.jpg','1');
REPLACE INTO "tbl_dagent" ("agent_id", "agent_name", "agent_age", "agent_gender", "agent_phone", "agent_dob", "agent_email", "place_id", "agent_address", "agent_uname", "agent_pswd", "agent_proof_type", "agent_proof_no", "agent_proof", "agent_dlicense_no", "agent_dlicense", "agent_photo", "agent_vstatus") VALUES
	('12','Vinod','25','male','7025210238','2002-08-29','arjunvinod2908@gmail.com','13','Chathamangalam,kannur','vinod123','vinod123','Aadhar','986598547856','agent_proof1268.jpg','DL2256485454','dagent_license1598.jpg','agent_photo1061.jpg','1');
/*!40000 ALTER TABLE "tbl_dagent" ENABLE KEYS;*/
UNLOCK TABLES;


#
# Table structure for table 'tbl_district'
#

CREATE TABLE /*!32312 IF NOT EXISTS*/ "tbl_district" (
  "district_id" int(10) unsigned NOT NULL auto_increment,
  "district_name" varchar(50) default NULL,
  PRIMARY KEY  ("district_id")
) AUTO_INCREMENT=18;



#
# Dumping data for table 'tbl_district'
#

LOCK TABLES "tbl_district" WRITE;
/*!40000 ALTER TABLE "tbl_district" DISABLE KEYS;*/
REPLACE INTO "tbl_district" ("district_id", "district_name") VALUES
	('3','Kozhikode');
REPLACE INTO "tbl_district" ("district_id", "district_name") VALUES
	('4','Ernkaulam');
REPLACE INTO "tbl_district" ("district_id", "district_name") VALUES
	('6','Kannur');
REPLACE INTO "tbl_district" ("district_id", "district_name") VALUES
	('7','Wayanad');
REPLACE INTO "tbl_district" ("district_id", "district_name") VALUES
	('8','Kasargode');
REPLACE INTO "tbl_district" ("district_id", "district_name") VALUES
	('9','Malappuram');
REPLACE INTO "tbl_district" ("district_id", "district_name") VALUES
	('10','Thrissur');
REPLACE INTO "tbl_district" ("district_id", "district_name") VALUES
	('11','Thiruvananthapuram');
REPLACE INTO "tbl_district" ("district_id", "district_name") VALUES
	('12','Kollam');
REPLACE INTO "tbl_district" ("district_id", "district_name") VALUES
	('13','Alappuzha');
REPLACE INTO "tbl_district" ("district_id", "district_name") VALUES
	('14','Kottayam');
REPLACE INTO "tbl_district" ("district_id", "district_name") VALUES
	('15','Palakkad');
REPLACE INTO "tbl_district" ("district_id", "district_name") VALUES
	('16','Idukki');
REPLACE INTO "tbl_district" ("district_id", "district_name") VALUES
	('17','Pathanamthitta');
/*!40000 ALTER TABLE "tbl_district" ENABLE KEYS;*/
UNLOCK TABLES;


#
# Table structure for table 'tbl_dosage'
#

CREATE TABLE /*!32312 IF NOT EXISTS*/ "tbl_dosage" (
  "dosage_id" int(10) unsigned NOT NULL auto_increment,
  "dosage_level" varchar(50) default NULL,
  PRIMARY KEY  ("dosage_id")
) AUTO_INCREMENT=15;



#
# Dumping data for table 'tbl_dosage'
#

LOCK TABLES "tbl_dosage" WRITE;
/*!40000 ALTER TABLE "tbl_dosage" DISABLE KEYS;*/
REPLACE INTO "tbl_dosage" ("dosage_id", "dosage_level") VALUES
	('5','10 mg');
REPLACE INTO "tbl_dosage" ("dosage_id", "dosage_level") VALUES
	('6','50 mg');
REPLACE INTO "tbl_dosage" ("dosage_id", "dosage_level") VALUES
	('7','250 mg');
REPLACE INTO "tbl_dosage" ("dosage_id", "dosage_level") VALUES
	('8','100 mg');
REPLACE INTO "tbl_dosage" ("dosage_id", "dosage_level") VALUES
	('9','200 mg');
REPLACE INTO "tbl_dosage" ("dosage_id", "dosage_level") VALUES
	('10','500 mg');
REPLACE INTO "tbl_dosage" ("dosage_id", "dosage_level") VALUES
	('11','120 mg');
REPLACE INTO "tbl_dosage" ("dosage_id", "dosage_level") VALUES
	('12','125 mg');
REPLACE INTO "tbl_dosage" ("dosage_id", "dosage_level") VALUES
	('13','75 mg');
REPLACE INTO "tbl_dosage" ("dosage_id", "dosage_level") VALUES
	('14','62.5 mg');
/*!40000 ALTER TABLE "tbl_dosage" ENABLE KEYS;*/
UNLOCK TABLES;


#
# Table structure for table 'tbl_equipments'
#

CREATE TABLE /*!32312 IF NOT EXISTS*/ "tbl_equipments" (
  "equipment_id" int(10) unsigned NOT NULL auto_increment,
  "equipment_name" varchar(50) default NULL,
  "equipment_company" varchar(50) default NULL,
  "equipment_description" varchar(50) default NULL,
  "equipment_image" varchar(50) default NULL,
  "equipment_price" varchar(50) default NULL,
  PRIMARY KEY  ("equipment_id")
) AUTO_INCREMENT=2;



#
# Dumping data for table 'tbl_equipments'
#

LOCK TABLES "tbl_equipments" WRITE;
/*!40000 ALTER TABLE "tbl_equipments" DISABLE KEYS;*/
REPLACE INTO "tbl_equipments" ("equipment_id", "equipment_name", "equipment_company", "equipment_description", "equipment_image", "equipment_price") VALUES
	('1','syringe',NULL,'sdxasdasxas','Screenshot (2).png','250');
/*!40000 ALTER TABLE "tbl_equipments" ENABLE KEYS;*/
UNLOCK TABLES;


#
# Table structure for table 'tbl_feedback'
#

CREATE TABLE /*!32312 IF NOT EXISTS*/ "tbl_feedback" (
  "feedback_id" int(10) unsigned NOT NULL auto_increment,
  "feedback_content" varchar(50) default NULL,
  "feedback_date" varchar(50) default NULL,
  "user_id" int(10) unsigned default NULL,
  PRIMARY KEY  ("feedback_id")
) AUTO_INCREMENT=5;



#
# Dumping data for table 'tbl_feedback'
#

LOCK TABLES "tbl_feedback" WRITE;
/*!40000 ALTER TABLE "tbl_feedback" DISABLE KEYS;*/
REPLACE INTO "tbl_feedback" ("feedback_id", "feedback_content", "feedback_date", "user_id") VALUES
	('1','atta flop','2024-11-12','11');
REPLACE INTO "tbl_feedback" ("feedback_id", "feedback_content", "feedback_date", "user_id") VALUES
	('2','hiiiiii','2024-11-12','11');
REPLACE INTO "tbl_feedback" ("feedback_id", "feedback_content", "feedback_date", "user_id") VALUES
	('3','fdfdsfzdczxc','2024-11-13','11');
REPLACE INTO "tbl_feedback" ("feedback_id", "feedback_content", "feedback_date", "user_id") VALUES
	('4','fesfsf','2024-11-09','13');
/*!40000 ALTER TABLE "tbl_feedback" ENABLE KEYS;*/
UNLOCK TABLES;


#
# Table structure for table 'tbl_medcompany'
#

CREATE TABLE /*!32312 IF NOT EXISTS*/ "tbl_medcompany" (
  "medCompany_id" int(10) unsigned NOT NULL auto_increment,
  "medCompany_name" varchar(50) default NULL,
  PRIMARY KEY  ("medCompany_id")
) AUTO_INCREMENT=12;



#
# Dumping data for table 'tbl_medcompany'
#

LOCK TABLES "tbl_medcompany" WRITE;
/*!40000 ALTER TABLE "tbl_medcompany" DISABLE KEYS;*/
REPLACE INTO "tbl_medcompany" ("medCompany_id", "medCompany_name") VALUES
	('5','Pfizer');
REPLACE INTO "tbl_medcompany" ("medCompany_id", "medCompany_name") VALUES
	('6','Cipla');
REPLACE INTO "tbl_medcompany" ("medCompany_id", "medCompany_name") VALUES
	('7','Sun Pharmaceutical');
REPLACE INTO "tbl_medcompany" ("medCompany_id", "medCompany_name") VALUES
	('8','Divis Lab');
REPLACE INTO "tbl_medcompany" ("medCompany_id", "medCompany_name") VALUES
	('9','Mankind Pharma');
REPLACE INTO "tbl_medcompany" ("medCompany_id", "medCompany_name") VALUES
	('10','Ajanta Pharma');
REPLACE INTO "tbl_medcompany" ("medCompany_id", "medCompany_name") VALUES
	('11','Lupin');
/*!40000 ALTER TABLE "tbl_medcompany" ENABLE KEYS;*/
UNLOCK TABLES;


#
# Table structure for table 'tbl_medicalshop'
#

CREATE TABLE /*!32312 IF NOT EXISTS*/ "tbl_medicalshop" (
  "shop_id" int(10) unsigned NOT NULL auto_increment,
  "place_id" int(10) unsigned default NULL,
  "shop_name" varchar(50) default NULL,
  "shop_address" varchar(50) default NULL,
  "shop_email" varchar(50) default NULL,
  "shop_password" varchar(50) default NULL,
  "shop_owner" varchar(50) default NULL,
  "shop_license" varchar(50) default NULL,
  "shop_licenseno" varchar(50) default NULL,
  "shop_proof" varchar(50) default NULL,
  "shop_photo" varchar(50) default NULL,
  "shop_vstatus" int(10) unsigned default '0',
  "shop_prooftype" varchar(50) default NULL,
  PRIMARY KEY  ("shop_id")
) AUTO_INCREMENT=22;



#
# Dumping data for table 'tbl_medicalshop'
#

LOCK TABLES "tbl_medicalshop" WRITE;
/*!40000 ALTER TABLE "tbl_medicalshop" DISABLE KEYS;*/
REPLACE INTO "tbl_medicalshop" ("shop_id", "place_id", "shop_name", "shop_address", "shop_email", "shop_password", "shop_owner", "shop_license", "shop_licenseno", "shop_proof", "shop_photo", "shop_vstatus", "shop_prooftype") VALUES
	('18','13','Madhava Medicals','Madhava Medicals Kannur','abhinavrameshan36@gmail.com','m12345','Madhava','shop_license1323.jpg','598745896542','Aadhar','shop_photo2105.png','1','Aadhar');
REPLACE INTO "tbl_medicalshop" ("shop_id", "place_id", "shop_name", "shop_address", "shop_email", "shop_password", "shop_owner", "shop_license", "shop_licenseno", "shop_proof", "shop_photo", "shop_vstatus", "shop_prooftype") VALUES
	('19','9','Pharma Medicare','Pharma Medicare Kannur','aromalkovilakathuparambil@gmail.com','a12345','Aromal','shop_license1510.jpg','521689754952','Aadhar','shop_photo1666.jpg','1','Aadhar');
REPLACE INTO "tbl_medicalshop" ("shop_id", "place_id", "shop_name", "shop_address", "shop_email", "shop_password", "shop_owner", "shop_license", "shop_licenseno", "shop_proof", "shop_photo", "shop_vstatus", "shop_prooftype") VALUES
	('20','13','Pharma Medicare','Pharma Medicare Kannur','aromalkovilakathuparambil@gmail.com','1234','Aromal','shop_license1620.jpg','521689754952','Aadhar','shop_photo2090.jpg','0','Aadhar');
REPLACE INTO "tbl_medicalshop" ("shop_id", "place_id", "shop_name", "shop_address", "shop_email", "shop_password", "shop_owner", "shop_license", "shop_licenseno", "shop_proof", "shop_photo", "shop_vstatus", "shop_prooftype") VALUES
	('21','13','MediPharma','Mele Chovva,Kannur','sng23mca024@sngce.ac.in','12345','Arjun','shop_license1665.jpg','DM456464546548','License','shop_photo2103.jpg','0','Aadhar');
/*!40000 ALTER TABLE "tbl_medicalshop" ENABLE KEYS;*/
UNLOCK TABLES;


#
# Table structure for table 'tbl_medicategory'
#

CREATE TABLE /*!32312 IF NOT EXISTS*/ "tbl_medicategory" (
  "mediCategory_id" int(10) unsigned NOT NULL auto_increment,
  "medi_Category" varchar(50) default NULL,
  PRIMARY KEY  ("mediCategory_id")
) AUTO_INCREMENT=12;



#
# Dumping data for table 'tbl_medicategory'
#

LOCK TABLES "tbl_medicategory" WRITE;
/*!40000 ALTER TABLE "tbl_medicategory" DISABLE KEYS;*/
REPLACE INTO "tbl_medicategory" ("mediCategory_id", "medi_Category") VALUES
	('6','Anti - Histamines');
REPLACE INTO "tbl_medicategory" ("mediCategory_id", "medi_Category") VALUES
	('7','Antacid');
REPLACE INTO "tbl_medicategory" ("mediCategory_id", "medi_Category") VALUES
	('8','Antifungal');
REPLACE INTO "tbl_medicategory" ("mediCategory_id", "medi_Category") VALUES
	('9','Corticosteroid');
REPLACE INTO "tbl_medicategory" ("mediCategory_id", "medi_Category") VALUES
	('10','Antiviral');
REPLACE INTO "tbl_medicategory" ("mediCategory_id", "medi_Category") VALUES
	('11','Beta-blockers');
/*!40000 ALTER TABLE "tbl_medicategory" ENABLE KEYS;*/
UNLOCK TABLES;


#
# Table structure for table 'tbl_medicine'
#

CREATE TABLE /*!32312 IF NOT EXISTS*/ "tbl_medicine" (
  "medicine_id" int(10) unsigned NOT NULL auto_increment,
  "age_id" varchar(50) default NULL,
  "dosage_id" varchar(50) default NULL,
  "mediCategory_id" int(10) unsigned default NULL,
  "medCompany_id" int(10) unsigned default NULL,
  "medicine_name" varchar(50) default NULL,
  "medicine_description" varchar(50) default NULL,
  "medicine_photo" varchar(50) default NULL,
  "medicine_price" varchar(50) default NULL,
  "medicine_mfd" varchar(50) default NULL,
  "medicine_expiry" varchar(50) default NULL,
  "shop_id" int(11) unsigned default NULL,
  PRIMARY KEY  ("medicine_id")
) AUTO_INCREMENT=22;



#
# Dumping data for table 'tbl_medicine'
#

LOCK TABLES "tbl_medicine" WRITE;
/*!40000 ALTER TABLE "tbl_medicine" DISABLE KEYS;*/
REPLACE INTO "tbl_medicine" ("medicine_id", "age_id", "dosage_id", "mediCategory_id", "medCompany_id", "medicine_name", "medicine_description", "medicine_photo", "medicine_price", "medicine_mfd", "medicine_expiry", "shop_id") VALUES
	('18','3','5','6','5','AntiHistamines','For Gastro','medicinePhoto_2035.jpg','50','2/08/2024','09-07-2025','18');
REPLACE INTO "tbl_medicine" ("medicine_id", "age_id", "dosage_id", "mediCategory_id", "medCompany_id", "medicine_name", "medicine_description", "medicine_photo", "medicine_price", "medicine_mfd", "medicine_expiry", "shop_id") VALUES
	('19','4','7','7','6','Antacid','For Lungs','medicinePhoto_1847.jpg','35','2/08/2024','10/10/2024','19');
REPLACE INTO "tbl_medicine" ("medicine_id", "age_id", "dosage_id", "mediCategory_id", "medCompany_id", "medicine_name", "medicine_description", "medicine_photo", "medicine_price", "medicine_mfd", "medicine_expiry", "shop_id") VALUES
	('20','7','6','9','7','Corticosteroid Manos','For Kidney Diseases','medicinePhoto_1508.jpg','75','2/08/2024','23-08-2026','19');
REPLACE INTO "tbl_medicine" ("medicine_id", "age_id", "dosage_id", "mediCategory_id", "medCompany_id", "medicine_name", "medicine_description", "medicine_photo", "medicine_price", "medicine_mfd", "medicine_expiry", "shop_id") VALUES
	('21','5','7','8','7','Antifungal Medicine','For Heart','medicinePhoto_1708.jpg','50','02/05/2024','03/05/2025','19');
/*!40000 ALTER TABLE "tbl_medicine" ENABLE KEYS;*/
UNLOCK TABLES;


#
# Table structure for table 'tbl_place'
#

CREATE TABLE /*!32312 IF NOT EXISTS*/ "tbl_place" (
  "place_id" int(10) unsigned NOT NULL auto_increment,
  "district_id" int(10) unsigned default NULL,
  "place_name" varchar(50) default NULL,
  "place_pincode" varchar(50) default NULL,
  PRIMARY KEY  ("place_id")
) AUTO_INCREMENT=16;



#
# Dumping data for table 'tbl_place'
#

LOCK TABLES "tbl_place" WRITE;
/*!40000 ALTER TABLE "tbl_place" DISABLE KEYS;*/
REPLACE INTO "tbl_place" ("place_id", "district_id", "place_name", "place_pincode") VALUES
	('6','3','Calicut Beach','673001');
REPLACE INTO "tbl_place" ("place_id", "district_id", "place_name", "place_pincode") VALUES
	('7','3','Chathamangalam','673601');
REPLACE INTO "tbl_place" ("place_id", "district_id", "place_name", "place_pincode") VALUES
	('8','3','Kattippara','673571');
REPLACE INTO "tbl_place" ("place_id", "district_id", "place_name", "place_pincode") VALUES
	('9','4','Udayamperoor','682307');
REPLACE INTO "tbl_place" ("place_id", "district_id", "place_name", "place_pincode") VALUES
	('10','4','Thrikkalathoor','683541');
REPLACE INTO "tbl_place" ("place_id", "district_id", "place_name", "place_pincode") VALUES
	('11','4','Muvattupuzha','679462');
REPLACE INTO "tbl_place" ("place_id", "district_id", "place_name", "place_pincode") VALUES
	('12','4','Perumbavoor','683545');
REPLACE INTO "tbl_place" ("place_id", "district_id", "place_name", "place_pincode") VALUES
	('13','6','Melechovva','680001');
REPLACE INTO "tbl_place" ("place_id", "district_id", "place_name", "place_pincode") VALUES
	('14','6','Thalassery','657980');
REPLACE INTO "tbl_place" ("place_id", "district_id", "place_name", "place_pincode") VALUES
	('15','6','Azhikode','670009');
/*!40000 ALTER TABLE "tbl_place" ENABLE KEYS;*/
UNLOCK TABLES;


#
# Table structure for table 'tbl_review'
#

CREATE TABLE /*!32312 IF NOT EXISTS*/ "tbl_review" (
  "review_id" int(11) NOT NULL auto_increment,
  "user_name" varchar(100) NOT NULL,
  "user_rating" varchar(100) NOT NULL,
  "user_review" varchar(100) NOT NULL,
  "review_datetime" varchar(100) NOT NULL,
  "medicine_id" int(11) NOT NULL,
  PRIMARY KEY  ("review_id")
);



#
# Dumping data for table 'tbl_review'
#

# No data found.



#
# Table structure for table 'tbl_stock'
#

CREATE TABLE /*!32312 IF NOT EXISTS*/ "tbl_stock" (
  "stock_id" int(10) unsigned NOT NULL auto_increment,
  "medicine_id" int(50) default NULL,
  "stock_qnty" int(11) default NULL,
  "stock_date" date default NULL,
  PRIMARY KEY  ("stock_id")
) AUTO_INCREMENT=20;



#
# Dumping data for table 'tbl_stock'
#

LOCK TABLES "tbl_stock" WRITE;
/*!40000 ALTER TABLE "tbl_stock" DISABLE KEYS;*/
REPLACE INTO "tbl_stock" ("stock_id", "medicine_id", "stock_qnty", "stock_date") VALUES
	('16',18,20,'2024-11-07');
REPLACE INTO "tbl_stock" ("stock_id", "medicine_id", "stock_qnty", "stock_date") VALUES
	('17',19,50,'2024-11-07');
REPLACE INTO "tbl_stock" ("stock_id", "medicine_id", "stock_qnty", "stock_date") VALUES
	('18',20,30,'2024-11-01');
REPLACE INTO "tbl_stock" ("stock_id", "medicine_id", "stock_qnty", "stock_date") VALUES
	('19',21,10,'2024-11-15');
/*!40000 ALTER TABLE "tbl_stock" ENABLE KEYS;*/
UNLOCK TABLES;


#
# Table structure for table 'tbl_user'
#

CREATE TABLE /*!32312 IF NOT EXISTS*/ "tbl_user" (
  "user_id" int(10) unsigned NOT NULL auto_increment,
  "user_name" varchar(50) default NULL,
  "user_age" int(10) unsigned default NULL,
  "user_gender" varchar(30) default NULL,
  "user_phone" varchar(20) default NULL,
  "user_dob" varchar(50) default NULL,
  "user_email" varchar(50) default NULL,
  "place_id" int(10) unsigned default NULL,
  "user_address" varchar(50) default NULL,
  "user_uname" varchar(50) default NULL,
  "user_pswd" varchar(50) default NULL,
  "proof_type" varchar(50) default NULL,
  "proof_no" varchar(50) default NULL,
  "user_proof" varchar(50) default NULL,
  "user_photo" varchar(50) default NULL,
  PRIMARY KEY  ("user_id")
) AUTO_INCREMENT=16;



#
# Dumping data for table 'tbl_user'
#

LOCK TABLES "tbl_user" WRITE;
/*!40000 ALTER TABLE "tbl_user" DISABLE KEYS;*/
REPLACE INTO "tbl_user" ("user_id", "user_name", "user_age", "user_gender", "user_phone", "user_dob", "user_email", "place_id", "user_address", "user_uname", "user_pswd", "proof_type", "proof_no", "user_proof", "user_photo") VALUES
	('14','AROMAL RAJU','23','male','9846125621','2002-08-02','aromalkovilakathuparambil@gmail.com','6','KOVILAKAM HOUSE, THRIKKALATHOOR','aromal123','aromal123','Aadhar','521689754952','user_proof1944.jpg','user_photo1458.jpg');
REPLACE INTO "tbl_user" ("user_id", "user_name", "user_age", "user_gender", "user_phone", "user_dob", "user_email", "place_id", "user_address", "user_uname", "user_pswd", "proof_type", "proof_no", "user_proof", "user_photo") VALUES
	('15','Manu','23','male','8075196411','2002-08-02','arjunachu2908@gmail.com','6','Kannur,Melechovva','manu','manu','Aadhar','956845215896','user_proof1643.jpg','user_photo1198.jpg');
/*!40000 ALTER TABLE "tbl_user" ENABLE KEYS;*/
UNLOCK TABLES;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE;*/
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;*/
